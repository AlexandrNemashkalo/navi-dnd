48 elf portraits, revision 2

elf-01.png through elf-48.png: 32x32 RGBA PNG, row-major order from the supplied reference.
Transparent background: alpha is exactly 0 outside the silhouette and 255 inside.
Every portrait has at least a one-pixel transparent canvas border.

Rebuilt from the matching original preview sheet:
https://img.craftpix.net/2021/08/Elf-Avatar-Icons-Pixel-Art2.webp
Background extraction: built-in image_gen, followed by actual row/column bounds,
connected silhouette extraction and nearest-neighbor scaling into a 30x30 area.
AI processing may alter small details. These are processed preview images, not original pack files.

preview-light.png, preview-dark.png and preview-checker.png are diagnostic contact sheets;
their backgrounds are only for visual inspection, not part of the individual PNGs.
manifest.json records each source bounding box and final opaque/transparent pixel count.
build.ps1 reproduces the export from processed-sheet.png on Windows with System.Drawing.
The PNG assets themselves are platform-independent; in-game rendering on Windows/macOS was not tested.
