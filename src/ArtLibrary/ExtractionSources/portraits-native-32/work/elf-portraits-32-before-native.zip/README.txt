﻿Source: user supplied 8-column, 6-row preview of 48 elf portraits.
Processing: built-in image_gen background extraction; generated sheet split in row-major order, nearest-neighbor resampling to 32x32, alpha threshold 128.
Prompt: Preserve all 48 characters in original order and pixel-art style. Remove brown backgrounds, frames and gutters to true transparency. Keep equal square cells in an 8x6 sheet, no text or new characters.
AI editing can change small details; these are processed from the preview, not original pack files.
Files elf-01.png through elf-48.png are the individual game assets. preview.png is an enlarged contact sheet only.
